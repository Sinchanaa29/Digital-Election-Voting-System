# `@typescript-eslint/visitor-keys`

> Visitor keys used to help traverse the TypeScript-ESTree AST.

## ✋ Internal Package

This is an _internal package_ to the [typescript-eslint monorepo](https://github.com/typescript-eslint/typescript-eslint).
You likely don't want to use it directly.

👉 See **https://typescript-eslint.io** for docs on typescript-eslint.
